from django.apps import AppConfig


class OnboardingCoreConfig(AppConfig):
    name = 'onboarding_core'
