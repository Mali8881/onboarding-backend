from django.contrib import admin
from .models import User, Role, Permission, Department, Position, AuditLog, LoginHistory


@admin.register(User)
class UserAdmin(admin.ModelAdmin):
    list_display = ("username", "role", "is_blocked")
    list_filter = ("role", "is_blocked")


admin.site.register(Role)
admin.site.register(Permission)
admin.site.register(Department)
admin.site.register(Position)
admin.site.register(AuditLog)
admin.site.register(LoginHistory)

